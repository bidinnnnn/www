<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Translator extends CI_Controller {
	
	function __construct(){
		parent::__construct();	
		
		$this->load->model('Mymodel','m');
		$this->load->helpers('form');
		$this->load->helpers('url');

        $this->sid = 0;
		
	}
	
	public function index(){

	    if( $this->input->get('agent') > 0 ){

            //$this->load->library('user_agent');

            //$this->browser = $this->agent->browser();
            //$this->browser_version = $this->agent->version();
            //$this->os = $this->agent->platform();
            //$this->ip_address = $this->input->ip_address();


            if ($this->agent->is_browser()){

                $this->agent = array(
                    'browser' => $this->agent->browser(),
                    'browser_version' => $this->agent->version(),
                    'os' => $this->agent->platform(),
                    'ip_address' => $this->input->ip_address()
                );

            }elseif ($this->agent->is_robot()){

                $this->agent = array(
                    'os' => $this->agent->platform(),
                    'ip_address' => $this->input->ip_address()
                );

            }elseif ($this->agent->is_mobile()){

                $this->agent = array(
                    'os' => $this->agent->platform(),
                    'ip_address' => $this->input->ip_address()
                );

            }else{
                $this->agent = 'Unidentified User Agent';
            }

            $sid = session_id();
            $this->sid = $this->session->userdata('sid');
            if(!$this->sid ) $this->session->set_userdata(array('sid'=>$sid));


        }


		$versi = (int)$this->input->get('versi',true);
		$mode = (int)$this->input->get('mode',true);
		$bahasa = $this->input->get('bahasa',true);
		$text = $this->input->get('text',true);
		
		if(isset($versi) && $versi == 2 ){
	
		if(isset($mode) && isset($bahasa) && isset($text) && !empty($text)){

			$text = $this->cleanCharFirst2($text);


			$words = $text;
			if ($this->db->table_exists("daerah_".$bahasa) && sizeof( explode(" ", $text) ) > 0 ){
				$words = explode(" ", $text);

				if($mode != 2){

					$indonesia_kata = array();
					$indonesia = "";
					$kata = array();
					$kata_alternatif = array();
					for($i=0; $i<sizeof($words); $i++){

						if($i > 0){
							$indonesia.= " ";
						}
						
						$word_text = $this->cleanChar($words[$i]);

						$this->db->select('*')->from('daerah_' . $bahasa);
						$this->db->where('daerah',$word_text);
						$this->db->limit(2);
						$q1 = $this->db->get();
						
						if ( $q1->num_rows() > 0) {
							$z = 0;
							$a = "";
							foreach($q1->result_array() as $r){

								if($z == 0){
									if( !empty($r['indonesia']) ){
										$a = $r['indonesia'];
										$indonesia = $indonesia . $r['indonesia'];


										$array_push = array();
										$array_push['k']	= $r['indonesia'];
										$array_push['t'] = 1;
										array_push($indonesia_kata, $array_push);
									}else{
										$indonesia = $indonesia . "<u>$word_text</u>";
										$kata[] = $word_text;								

										$array_push = array();
										$array_push['k']	= $word_text;
										$array_push['t'] = 0;
										array_push($indonesia_kata, $array_push);
									}
								}					


								//alternatif kata
								if($z == 1){
									$kata_alternatif[] = array('a'=>$a,'b'=>$r['indonesia']);
								}

								$z++;
							}

						}else{
							$indonesia = $indonesia . "<u>$word_text</u>";

							$kata[] = $word_text;


							$array_push = array();
							$array_push['k']	= $word_text;
							$array_push['t'] = 0;
							array_push($indonesia_kata, $array_push);
						}
					}


					$tanggal = date('Y-m-d H:i:s');
					for($x=0;$x < sizeof($kata);$x++){
                        if(!empty($kata[$x]) ){

                            $data_kata = $this->db->get_where("kata",array("text" => $kata[$x]));
                            if($data_kata->num_rows() > 0){

                                $hits = 0;
                                foreach ($data_kata->result() as $row){
                                    $hits = $row->hits+1;
                                }

                                $this->db->where(array("text" => $kata[$x], 'bahasa' => $bahasa));
                                $this->db->update("kata",array("hits" => $hits));

                            }else{

                                $this->db->insert('kata',array(
                                    'text' => $kata[$x],
                                    'bahasa' => $bahasa,
                                    'mode' => 2,
                                    'waktu' => $tanggal,
                                    //'agent' => json_encode( $this->agent )
                                ));

                            }


                        }
						
						//mysqli_query($connection,"INSERT INTO ".$prefix."kata (text,bahasa,mode,waktu) VALUES('$kata[$x]','$bahasa',2,'$tanggal')");
					}
					
					
					
					$text_translate = '';
					foreach($indonesia_kata as $k){
						$text_translate.=' '.$k['k'];
					}
					
					$text_translate = ltrim($text_translate, ' '); 


					/**
					$this->db->insert('history',array(
						'text' => $text,
						'text_translate' => $text_translate,
						'bahasa' => $bahasa,
						'mode' => 2,
						'waktu' => $tanggal,
						'sid' => $this->sid,
						//'agent' => json_encode( $this->agent )
					));*/
					//mysqli_query($connection,"INSERT INTO ".$prefix."history (text,bahasa,mode,waktu) VALUES('$text','$bahasa',2,'$tanggal')");

					$response["mode"] = (int)$mode;
					$response["bahasa"] = $bahasa;
					$response["success"] = true;	
					//$response["response"] = array("daerah"=>$text,"indonesia"=>$indonesia,"alternatif" => $kata_alternatif);
					$response["response"] = array("daerah"=>$text,"indonesia"=>$indonesia_kata,"alternatif" => $kata_alternatif);		

					header('Content-type: application/json; charset=utf-8');
					echo json_encode($response);
				}else{


					$daerah_kata = array();
					$aksara_kata = array();

					$daerah = "";
					$aksara = "";
					$kata = array();
					$kata_alternatif = array();
					for($i=0; $i<sizeof($words); $i++){

						if($i > 0){
							$daerah.= " ";
							$aksara.= " ";
						}
						
						$word_text = $this->cleanChar($words[$i]);

						
						$this->db->select('*')->from('daerah_' . $bahasa);
						$this->db->where('indonesia',$word_text);
						$this->db->limit(2);
						$q2 = $this->db->get();
						
						//$query = mysqli_query($connection,"SELECT * FROM ".$prefix."daerah_$bahasa WHERE indonesia='$word_text' LIMIT 2");
						if ( $q2->num_rows() > 0) {
							$z = 0;
							$a = "";
							foreach($q2->result_array() as $r){

								if($z == 0){
									if( !empty($r['daerah']) ){
										$a = $r['daerah'];
										$daerah = $daerah . $r['daerah'];

										$array_push = array();
										$array_push['k']	= $r['daerah'];
										$array_push['t'] = 1;
										array_push($daerah_kata, $array_push);
									}else{
										$daerah = $daerah . "<u>$word_text</u>";
										$kata[] = $word_text;


										$array_push = array();
										$array_push['k']	= $word_text;
										$array_push['t'] = 0;
										array_push($daerah_kata, $array_push);
									}

									if( !empty($r['aksara']) ){
										$aksara = $aksara . $r['aksara'];	

										$array_push = array();
										$array_push['k']	= $r['aksara'];
										$array_push['t'] = 1;
										array_push($aksara_kata, $array_push);				
									}else{
										$aksara = $aksara . "<u>$word_text</u>";

										$array_push = array();
										$array_push['k']	= $word_text;
										$array_push['t'] = 0;
										array_push($aksara_kata, $array_push);							
									}							
								}

								//alternatif kata
								if($z == 1){
									$kata_alternatif[] = array('a'=>$a,'b'=>$r['daerah']);
								}

								$z++;
							}
						}else{
							$daerah = $daerah . "<u>$word_text</u>";
							$aksara = $aksara . "<u>$word_text</u>";

							$kata[] = $word_text;

							$array_push = array();
							$array_push['k']	= $word_text;
							$array_push['t'] = 0;
							array_push($daerah_kata, $array_push);


							$array_push = array();
							$array_push['k']	= $word_text;
							$array_push['t'] = 0;
							array_push($aksara_kata, $array_push);	
						}

					}

					$tanggal = date('Y-m-d H:i:s');
					for($x=0;$x < sizeof($kata);$x++){
						if(!empty($kata[$x]) ){

                            $data_kata = $this->db->get_where("kata",array("text" => $kata[$x], 'bahasa' => $bahasa));
                            if($data_kata->num_rows() > 0){

                                $hits = 0;
                                foreach ($data_kata->result() as $row){
                                    $hits = $row->hits+1;
                                }

                                $this->db->where(array("text" => $kata[$x]));
                                $this->db->update("kata",array("hits" => $hits));
                            }else{

                                $this->db->insert('kata',array(
                                    'text' => $kata[$x],
                                    'bahasa' => $bahasa,
                                    'mode' => 1,
                                    'waktu' => $tanggal,
                                    //'agent' => json_encode( $this->agent )
                                ));

                            }


                        }
						
						//mysqli_query($connection,"INSERT INTO ".$prefix."kata (text,bahasa,mode,waktu) VALUES('$kata[$x]','$bahasa',1,'$tanggal')");
					}
					
					$text_translate = '';
					foreach($daerah_kata as $k){
						$text_translate.=' '.$k['k'];
					}
					
					$text_translate = ltrim($text_translate, ' '); 

					/**
					$this->db->insert('history',array(
						'text' => $text,
						'text_translate' => $text_translate,
						'bahasa' => $bahasa,
						'mode' => 1,
						'waktu' => $tanggal,
						'sid' => $this->sid,
						//'agent' => json_encode( $this->agent )
					));*/
					
					//mysqli_query($connection,"INSERT INTO ".$prefix."history (text,bahasa,mode,waktu) VALUES('$text','$bahasa',1,'$tanggal')");

					$response["mode"] = $mode;
					$response["bahasa"] = $bahasa;
					$response["success"] = true;	
					//$response["response"] = array("indonesia"=>$text,"daerah"=>array('kalimat'=>$daerah,'kata'=>$daerah_kata),"aksara"=>$aksara,"alternatif" => $kata_alternatif);	
					$response["response"] = array("indonesia"=>$text,"daerah"=>$daerah_kata,"aksara"=>$aksara_kata,"alternatif" => $kata_alternatif);	

					header('Content-type: application/json; charset=utf-8');
					echo json_encode($response);
				}
			}else{
					$response["success"] = false;
					$response["response"] = "";
					header('Content-type: application/json; charset=utf-8');
					echo json_encode($response);			
			}



		}else{		

			$response["success"] = false;
			$response["response"] = "Text atau bahasa tidak tersedia";
			header('Content-type: application/json; charset=utf-8');
			echo json_encode($response);
		}
		}else{		

			$response["success"] = false;
			$response["response"] = "Versi bahasa tidak didukung";
			header('Content-type: application/json; charset=utf-8');
			echo json_encode($response);
		}
		
	}

	public function get(){
        $response = array();
        $response["response"] = array();

	    $this->db->select('*')->from('lang');
        $this->db->where( 'aktif', 1 );
        $this->db->order_by('bahasa_desc','asc');

	    $query = $this->db->get();

	    if($query->num_rows() > 0 ){
            $response["success"] = true;

            foreach($query->result() as $r ){

                $querysz = $this->db->query("SELECT table_name AS 'Table', round((data_length + index_length), 2) as size FROM information_schema.TABLES WHERE table_schema = '".$this->db->database."' ORDER BY size DESC");

                $size = 0;
                $jumlah = 0;
                //$x = array();
                foreach ($querysz->result_array() as $r2){

                    //if( $r2['Table'] == "bade_daerah_".$r->bahasa_id )
                    //array_push($x, $r2['Table'] ."-> bade_daerah_".$r->bahasa_id .'->'.$r2['size'] );

                    if($r2['Table'] == "bade_daerah_".$r->bahasa_id ){
                        $size = $r2['size'];
                    }
                }

                $querysy = $this->db->query("SELECT * FROM bade_daerah_".$r->bahasa_id." WHERE daerah != '' ");
                if($querysy->num_rows() > 0){
                    $jumlah = $querysy->num_rows();
                }

                $array_push = array();
                //$array_push['x']	= $x;
                $array_push['bahasa_id']	= $r->bahasa_id;
                $array_push['bahasa_desc']	= $r->bahasa_desc;
                $array_push['versi']		= (int)$r->versi;
                $array_push['jumlah']		= (int)$jumlah;
                $array_push['ukuran']		= (int)$size;

                array_push($response["response"], $array_push);
            }
        }else{
            $response["success"] = false;
            $response["response"] = "Tidak ditemukan data";
        }


        header('Content-type: application/json; charset=utf-8');
        echo json_encode($response);

    }

    public function download(){
	    $bahasa = $this->input->get('bahasa');
        if( $this->_if_table_exists($this->db->dbprefix."daerah_" . $bahasa) ){

            $response = array();
            $query = $this->db->query("SELECT * FROM ".$this->db->dbprefix."daerah_$bahasa");
            if ( $query->num_rows() > 0) {

                foreach ($query->result_array() as $r){

                    $array_push = array();
                    $array_push['id'] = $r['id'];
                    $array_push['indonesia'] = $r['indonesia'];
                    $array_push['daerah'] = $r['daerah'];
                    $array_push['aksara'] = $r['aksara'];

                    array_push($response, $array_push);
                }


                header('Content-type: application/json; charset=utf-8');
                header('Content-Disposition: attachment; filename=' . $bahasa . '.json');
                echo json_encode($response);
            }
        }
    }

    public function kata(){
        $response = array();
        $response["response"] = array();

        $bahasa = $this->input->get('bahasa');
        if( $this->_if_table_exists($this->db->dbprefix."daerah_" . $bahasa) ){

            $query = $this->db->query("SELECT * FROM ".$this->db->dbprefix."daerah_$bahasa");
            if ( $query->num_rows() > 0) {

                $response["success"] = true;

                foreach ($query->result_array() as $r){

                    $array_push = array();
                    $array_push['id'] = $r['id'];
                    $array_push['indonesia'] = $r['indonesia'];
                    $array_push['daerah'] = $r['daerah'];
                    $array_push['aksara'] = $r['aksara'];

                    array_push($response["response"], $array_push);
                }

            }else{
                $response["success"] = false;
                $response["response"] = "Tidak ditemukan data";
            }
        }else{
            $response["success"] = false;
            $response["response"] = "Bahasa tidak ditemukan";
        }

        header('Content-type: application/json; charset=utf-8');
        echo json_encode($response);
    }

    function _if_table_exists($bahasa){
        $query = $this->db->query("SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = '$bahasa'");

        if($query->num_rows() > 0){
            return true;
        }
        return false;
    }
	
	function cleanChar($text){
		
		/*$text = preg_replace("/[-]/"," ",$text);
		$text = preg_replace("/[^A-Za-z0-9 -_]/","",$text);
		$text = preg_replace("/[^A-Za-z0-9\s-_]/","",$text);
		$text = preg_replace("/[^A-Za-z0-9[:space:]-_]/","",$text);*/
		
		return $text;
	}
	
	function cleanCharFirst($text){
		
		$text = preg_replace("/[-]/", " - ", $text);
		$text = preg_replace("/[,]/", " , ", $text);
		$text = preg_replace("/[.]/", " . ", $text);
		$text = preg_replace("/[!]/", " ! ", $text);
		$text = preg_replace("/[?]/", " ? ", $text);
		$text = preg_replace('/["]/', ' " ', $text);
		$text = preg_replace("/[']/", " ' ", $text);
		$text = preg_replace("/[  ]/", " ", $text);
		$text = preg_replace("/[^A-Za-z0-9,.?!'\"@-_ ]/", "", $text);
		
		return $text;
	}

    function cleanCharFirst2($text){
        $text = preg_replace("/[-]/", "-", $text);
        $text = preg_replace("/[,]/", " , ", $text);
        $text = preg_replace("/[.]/", " . ", $text);
        $text = preg_replace("/[!]/", " ! ", $text);
        $text = preg_replace("/[?]/", " ? ", $text);
        $text = preg_replace('/["]/', " ' ", $text);
        $text = preg_replace("/[']/", " ' ", $text);
        $text = preg_replace("/[  ]/", " ", $text);
        $text = preg_replace("/[^A-Za-z0-9,.?!'\"@-_ ]/", "", $text);

        return $text;
    }
	
	
}
