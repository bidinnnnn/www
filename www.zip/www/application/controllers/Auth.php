<?php

class Auth extends CI_Controller {

    function __construct() {
        parent::__construct();
		
    }

    function index(){		
		
		$level = $this->session->userdata('user_level');
		if ( $level == 'admin' ) redirect('admin/dashboard');
		else $this->load->view('auth/login');
		
    }
	
	function profile(){		
		
		if(!$this->session->userdata('user_level')){
			redirect('auth');
		}
		
		$users_data = $this->session->userdata();
		$users_data = $this->getUsersDetail($users_data);	
		
		$this->load->view('auth/profile',$users_data);
	}
	
	function sandi(){		
		
		if(!$this->session->userdata('user_level')){
			redirect('auth');
		}
		
		$users_data = $this->session->userdata();
		$users_data = $this->getUsersDetail($users_data);	
		
		$this->load->view('auth/sandi',$users_data);
	}
	
	function signin(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
			
		$data = array();
		if(empty($username) || empty($password)){			
			$data['pesan'] = '<div class="alert alert-danger" role="alert"><strong>Maaf!</strong> Username dan Password kosong!</div>';
		}else{		

			$this->db->where(array(
					'username'=> $username,
					'password'=> $password
			));

			$users_data = $this->db->get('users')->row_array();
			$users_data = $this->getUsersDetail($users_data);

			if ( !empty($users_data) && $users_data['user_level'] == 'admin' ) {
				
				$this->session->set_userdata($users_data);
				$data['pesan'] = '';
				$data['redirect'] = 'admin/dashboard';
			}else{
				$data['pesan'] = '<div class="alert alert-danger" role="alert"><strong>Maaf!</strong> Username dan Password tidak sesuai!</div>';
				$data['redirect'] = 'auth';
			}
		}
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($data);	
		
	}

    function logout() {
        $this->session->sess_destroy();
        redirect('auth');
    }
	
	
	function getUsersDetail($users){
		$baris = array();
		$baris['user_id'] = $users['user_id'];	
		$baris['username'] = $users['username'];	
		$baris['password'] = $users['password'];	
		$baris['user_level'] = $users['user_level'];
			
		
		return $baris;
	}
	
}