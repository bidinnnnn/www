<?php
defined('BASEPATH') or exit();

class Kata extends CI_Controller{
	function __construct(){
		parent::__construct();	
		
		$this->load->model('Mymodel','m');
		$this->load->helpers('form');
		$this->load->helpers('url');
		
		if($this->session->userdata('user_level') != 'admin'){
			redirect('auth/profile');
		}
		
		
		$this->user_id = $this->session->userdata('user_id');
	}
	
	function index(){
		$data['title'] = "Kata";
		$data['bahasa'] = $this->lang(true);
        $this->template->load('template','admin/kata',$data);
	}
	
	function bahasa($continue = false){
		
		$this->db->select('*');
		$this->db->from('kata');
		$this->db->group_by('bahasa');
		$this->db->order_by('bahasa','asc');
        //get records
        $query = $this->db->get();
		
		$data = array();
		foreach($query->result_array() as $row){
			
			$items = array();
			$items['bahasa_id'] = $row['bahasa'];
			$items['bahasa_desc'] = '';
			
			$lang =  $this->db->get_where('lang',array('bahasa_id' => $row['bahasa']))->result();
			$items['bahasa_desc'] = $lang[0]->bahasa_desc;
				
			
			array_push($data,$items);
		}
		
		if($continue) return $data;
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($data);	
	}
	
	function lang($continue = false){
		
		$this->db->select('*');
		$this->db->from('lang');
		$this->db->order_by('bahasa_desc','asc');
        //get records
        $query = $this->db->get();
		
		$data = array();
		foreach($query->result_array() as $row){
			
			$items = array();
			$items['bahasa_id'] = $row['bahasa_id'];
			$items['bahasa_desc'] = $row['bahasa_desc'];
				
			
			array_push($data,$items);
		}
		
		if($continue) return $data;
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($data);	
	}
	
	function getRows($params = array()){
        //$this->db->query('SELECT kata_id,text,bahasa,mode,waktu, COUNT(*) AS count FROM bade_kata GROUP BY text ORDER BY count DESC');            
		$this->db->select('kata_id,text,hits,bahasa,mode,waktu, COUNT(*) AS jumlah');
		$this->db->from('kata');
		
		if(!empty($params['search']['bahasaBy'])){
			$this->db->where('bahasa',$params['search']['bahasaBy']);
        }
		
        //filter data by searched keywords
        if(!empty($params['search']['keywords'])){
            $this->db->like('text',$params['search']['keywords']);
        }
		
        //sort data by ascending or desceding order
        if(!empty($params['search']['sortBy'])){
            $this->db->order_by('hits',$params['search']['sortBy']);
        }else{
            $this->db->order_by('hits','desc');
        }
		
		
		
		$this->db->group_by('text');
		$this->db->order_by('jumlah','desc');
		
        //set start and limit
        if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit'],$params['start']);
        }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit']);
        }
		
        //get records
        $query = $this->db->get();
		
		$data = array();
		foreach($query->result_array() as $row){
			
			$items = array();
			$items['kata_id'] = $row['kata_id'];
			$items['text'] = $row['text'];
			$items['bahasa'] = $row['bahasa'];
			$items['mode'] = $row['mode'];
			$items['waktu'] = $row['waktu'];
			$items['jumlah'] = $row['hits'];
				
			
			array_push($data,$items);
		}
		
		
        //return fetched data
        return $data;
    }
	
	function ajaxPaginationData(){
		
        $this->perPage = 10;
        $conditions = array();
        
        //calc offset number
        $page = $this->input->post('page');
        if(!$page){
            $offset = 0;
        }else{
            $offset = $page;
        }
        
        //set conditions for search
        $keywords = $this->input->post('keywords');
        $limitBy = $this->input->post('limitBy');
        $bahasaBy = $this->input->post('bahasaBy');
	
		
        if(!empty($keywords)){
            $conditions['search']['keywords'] = $keywords;
        }
        if(!empty($bahasaBy)){
            $conditions['search']['bahasaBy'] = $bahasaBy;
        }
        if(!empty($limitBy)){
            $this->perPage = (int) $limitBy;
        }
        
		
        //total rows count
        $totalRec = count($this->getRows($conditions));
        
        //pagination configuration
        $config['target']      = '#postList tbody';
        $config['base_url']    = base_url().'kata/ajaxPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['link_func']   = 'searchFilter';
		
		
		// integrate bootstrap pagination
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->ajax_pagination->initialize($config);
        
        //set start and limit
        $conditions['start'] = $offset;
        $conditions['limit'] = $this->perPage;
        
        //get posts data
        $data['empData'] = $this->getRows($conditions);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['pagination'] = $this->ajax_pagination->create_links();
        
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($data);	
    }
	
	
	function tambahdata(){					
						
		$kata_title = $this->input->post('kata_title');
		$kata_kd = $this->input->post('kata_kd');
		if( $kata_title == ""){
			$result['pesan'] = "Judul Katalog Kosong!";
		}elseif( $kata_kd == ""){
			$result['pesan'] = "Kode Katalog Kosong!";
		}else{
			$result['pesan'] = "";
			$data =  array(
				'user_id'=>$this->user_id,
				'pengaturan_key'=>$this->pengaturan_key,
				'kata_title' => $kata_title,
				'kata_kd' => $kata_kd
			);
			

			$this->db->insert('kata',$data);
			
			$id = $this->db->insert_id();
			$result['id'] = $id;
			
		}
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($result);
	}
	
	function simpandatabyid(){		
		$indonesia = $this->input->post('indonesia');	
		$daerah = $this->input->post('daerah');
		$aksara = $this->input->post('aksara');
		$bahasa = $this->input->post('bahasa');
		if( $indonesia == ""){
			$result['pesan'] = "Text Indonesia Kosong!";
		//}elseif( $daerah == ""){
			//$result['pesan'] = "Text Daerah Kosong!";
		}else{
			$result['pesan'] = "";
			
			
			$this->db->select('*')->from('daerah_' . $bahasa);
			$this->db->where('indonesia',$indonesia);
			$this->db->limit(1);
			
			$kata = $this->db->get();
			$jumlah = $kata->num_rows();
			//$d = $kata->result();
			
			if( $jumlah > 0 ){				
				
				$this->db->where('indonesia',$indonesia);
				$this->db->update('daerah_' . $bahasa, array(
					'daerah' => $daerah,
					'aksara' => $aksara,
					'status' => 1
				));

            }else{
				$this->db->insert('daerah_' . $bahasa,array(
					'indonesia' => $indonesia,
					'daerah' => $daerah,
					'aksara' => $aksara,
					'status' => 1
				));
			
				$id = $this->db->insert_id();
				$result['id'] = $id;
			}
			
			//$this->db->where($where);
			//$this->db->update('kata',$data);
			//$result['id'] = $kata->num_rows();
			
		}
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($result);
	}
	
	function ambildatabyid(){
		$text = $this->input->post('text');
		$bahasa = $this->input->post('bahasa');
		
		$where = array(
			'indonesia'=>$text
		);
		
		$kata = $this->m->ambilbyid($where,'daerah_' . $bahasa)->result();
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($kata);
	}
	
	
	function hapusdatabyid(){
		$text = $this->input->post('text');
		$bahasa = $this->input->post('bahasa');
		
		$where = array(
			'text'=>$text,
			'bahasa'=>$bahasa
		);
		$this->m->hapusbyid($where,'kata');		
		
	}
}

?>