<?php
defined('BASEPATH') or exit();

class Bahasa extends CI_Controller{
	function __construct(){
		parent::__construct();	
		
		$this->load->model('Mymodel','m');
		$this->load->helpers('form');
		$this->load->helpers('url');
		
		if($this->session->userdata('user_level') != 'admin'){
			redirect('auth/profile');
		}
		
		
		$this->user_id = $this->session->userdata('user_id');
	}
	
	function index(){
		$data['title'] = "Bahasa";
		
        $this->template->load('template','admin/bahasa',$data);
	}
	
	function lihat(){
		
		$data['lang'] = $this->input->get('lang');
		$data['title'] = "Lihat Bahasa";
		
        $this->template->load('template','admin/bahasa_lihat',$data);
	}
	
	
	
	function getRows($params = array()){
        $this->db->select('*');
        $this->db->from('lang');       
        //filter data by searched keywords
        if(!empty($params['search']['keywords'])){
            $this->db->like('bahasa_desc',$params['search']['keywords']);
        }
		
        //sort data by ascending or desceding order
        if(!empty($params['search']['sortBy'])){
            $this->db->order_by('bahasa_desc',$params['search']['sortBy']);
        }else{
            $this->db->order_by('bahasa_desc','asc');
        }
		
        //set start and limit
        if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit'],$params['start']);
        }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit']);
        }
		
        //get records
        $query = $this->db->get();
		
		$data = array();
		foreach($query->result_array() as $row){
			
			$jumlah = 0;
			
			if ($this->db->table_exists("daerah_".$row['bahasa_id']) ){
				$q1 = $this->db->select('*')->from("daerah_".$row['bahasa_id'])->get();
				$jumlah =  $q1->num_rows();
			}
			
			
			$items = array();
			$items['lang_id'] = $row['lang_id'];
			$items['bahasa_id'] = $row['bahasa_id'];
			$items['bahasa_desc'] = $row['bahasa_desc'];
			$items['versi'] = $row['versi'];
			$items['ukuran'] = $row['ukuran'];
			$items['jumlah'] = $jumlah;
			$items['aktif'] = $row['aktif'];
				
			
			array_push($data,$items);
		}
		
		
        //return fetched data
        return $data;
    }
	
	function ajaxPaginationData(){
		
        $this->perPage = 10;
        $conditions = array();
        
        //calc offset number
        $page = $this->input->post('page');
        if(!$page){
            $offset = 0;
        }else{
            $offset = $page;
        }
        
        //set conditions for search
        $keywords = $this->input->post('keywords');
        $sortBy = $this->input->post('sortBy');
	
		
        if(!empty($keywords)){
            $conditions['search']['keywords'] = $keywords;
        }
        if(!empty($sortBy)){
            $conditions['search']['sortBy'] = $sortBy;
        }
        if(!empty($limitBy)){
            $this->perPage = (int) $limitBy;
        }
        
		
        //total rows count
        $totalRec = count($this->getRows($conditions));
        
        //pagination configuration
        $config['target']      = '#postList tbody';
        $config['base_url']    = base_url().'bahasa/ajaxPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['link_func']   = 'searchFilter';
		
		
		// integrate bootstrap pagination
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->ajax_pagination->initialize($config);
        
        //set start and limit
        $conditions['start'] = $offset;
        $conditions['limit'] = $this->perPage;
        
        //get posts data
        $data['empData'] = $this->getRows($conditions);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['pagination'] = $this->ajax_pagination->create_links();
        
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($data);	
    }
	
	function getRowsKata($params = array()){
        //$this->db->query('SELECT kata_id,text,bahasa,mode,waktu, COUNT(*) AS count FROM bade_kata GROUP BY text ORDER BY count DESC');            
		$this->db->select('*');
		
		if(!empty($params['search']['bahasaBy'])){
			$this->db->from('daerah_'.$params['search']['bahasaBy']);
		}else{		
			$this->db->from('daerah_lampung_o');			
		}
		
        //filter data by searched keywords
        if(!empty($params['search']['keywords'])){
            $this->db->like('indonesia',$params['search']['keywords']);
        }
		
        //set start and limit
        if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit'],$params['start']);
        }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit']);
        }
		
        //get records
        $query = $this->db->get();
		
		$data = array();
		foreach($query->result_array() as $row){
			
			$items = array();
			$items['id'] = $row['id'];
			$items['indonesia'] = $row['indonesia'];
			$items['daerah'] = $row['daerah'];
			$items['aksara'] = $row['aksara'];
			$items['status'] = $row['status'];
				
			
			array_push($data,$items);
		}
		
		
        //return fetched data
        return $data;
    }
	
	function ajaxPaginationDataKata(){
		
        $this->perPage = 10;
        $conditions = array();
        
        //calc offset number
        $page = $this->input->post('page');
        if(!$page){
            $offset = 0;
        }else{
            $offset = $page;
        }
        
        //set conditions for search
        $keywords = $this->input->post('keywords');
        $limitBy = $this->input->post('limitBy');
        $bahasaBy = $this->input->post('bahasaBy');
	
		
        if(!empty($keywords)){
            $conditions['search']['keywords'] = $keywords;
        }
        if(!empty($bahasaBy)){
            $conditions['search']['bahasaBy'] = $bahasaBy;
        }
        if(!empty($limitBy)){
            $this->perPage = (int) $limitBy;
        }
        
		
        //total rows count
        $totalRec = count($this->getRowsKata($conditions));
        
        //pagination configuration
        $config['target']      = '#postList tbody';
        $config['base_url']    = base_url().'bahasa/ajaxPaginationDataKata';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['link_func']   = 'searchFilter';
		
		
		// integrate bootstrap pagination
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->ajax_pagination->initialize($config);
        
        //set start and limit
        $conditions['start'] = $offset;
        $conditions['limit'] = $this->perPage;
        
        //get posts data
        $data['empData'] = $this->getRowsKata($conditions);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['pagination'] = $this->ajax_pagination->create_links();
        
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($data);	
    }
	
	
	function tambahdata(){					
						
		$bahasa_id = $this->input->post('bahasa_id');
		$bahasa_desc = $this->input->post('bahasa_desc');
		$aktif = $this->input->post('aktif');
		if( $bahasa_id == ""){
			$result['pesan'] = "Kata ID Kosong!";
		}elseif( $bahasa_desc == ""){
			$result['pesan'] = "Kata Desc Kosong!";
		}else{
			$result['pesan'] = "";
			$data =  array(
				'bahasa_id'=>$bahasa_id,
				'bahasa_desc' => $bahasa_desc,
				'aktif' => $aktif
			);
			

			$this->db->insert('lang',$data);
			
			$id = $this->db->insert_id();
			$result['id'] = $id;
			
			if($id > 0){
				$this->db->query("CREATE TABLE ".$this->db->dbprefix("daerah_".$bahasa_id)." (
				  id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
				  indonesia TEXT NOT NULL,
				  daerah TEXT NOT NULL,
				  aksara TEXT NOT NULL,
				  status INT(1) NOT NULL
				  )");
			}
			
		}
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($result);
	}
	
	function tambahdatakata(){					
						
		$indonesia = $this->input->post('indonesia');
		$daerah = $this->input->post('daerah');
		$aksara = $this->input->post('aksara');
		$bahasa = $this->input->post('bahasa');
		if( $indonesia == ""){
			$result['pesan'] = "Aksara Kosong!";
		}else{
			$result['pesan'] = "";
			$data =  array(
				'indonesia'=>$indonesia,
				'daerah'=>$daerah,
				'aksara' => $aksara
			);
			

			$this->db->insert("daerah_".$bahasa,$data);
			
			$id = $this->db->insert_id();
			$result['id'] = $id;
			
		}
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($result);
	}
	
	function simpandatabyid(){		
		$id = $this->input->post('id');			
						
		$bahasa_id = $this->input->post('bahasa_id');
		$bahasa_desc = $this->input->post('bahasa_desc');
		$aktif = $this->input->post('aktif');
		if( $bahasa_id == ""){
			$result['pesan'] = "Kata ID Kosong!";
		}elseif( $bahasa_desc == ""){
			$result['pesan'] = "Kata Desc Kosong!";
		}else{
			$result['pesan'] = "";
			
			
			$where = array(
				'lang_id'=>$id
			);
			$data =  array(
				'bahasa_id'=>$bahasa_id,
				'bahasa_desc' => $bahasa_desc,
				'aktif' => $aktif
			);
			$this->db->where($where);
			$this->db->update('lang',$data);
			$result['id'] = $id;
			
		}
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($result);
	}
	
	function simpandatakatabyid(){	
		$indonesia = $this->input->post('indonesia');	
		$daerah = $this->input->post('daerah');
		$aksara = $this->input->post('aksara');
		$bahasa = $this->input->post('bahasa');
		if( $indonesia == ""){
			$result['pesan'] = "Text Indonesia Kosong!";
		//}elseif( $daerah == ""){
			//$result['pesan'] = "Text Daerah Kosong!";
		}else{
			$result['pesan'] = "";
			
			
			$this->db->select('*')->from('daerah_' . $bahasa);
			$this->db->where('indonesia',$indonesia);
			$this->db->limit(1);
			
			$kata = $this->db->get();
			$jumlah = $kata->num_rows();
			//$d = $kata->result();
			
			if( $jumlah > 0 ){				
				
				$this->db->where('indonesia',$indonesia);
				$this->db->update('daerah_' . $bahasa, array(
					'daerah' => $daerah,
					'aksara' => $aksara,
					'status' => 1
				));
				
			}else{
				$this->db->insert('daerah_' . $bahasa,array(
					'indonesia' => $indonesia,
					'daerah' => $daerah,
					'aksara' => $aksara,
					'status' => 1
				));
			
				$id = $this->db->insert_id();
				$result['id'] = $id;
			}
			
			//$this->db->where($where);
			//$this->db->update('kata',$data);
			//$result['id'] = $kata->num_rows();
			
		}
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($result);
	}
	
	function ambildatabyid(){
		$id =  $this->input->post('id');
		$where = array(
			'lang_id'=>$id
		);
		$bahasa = $this->m->ambilbyid($where,'lang')->result();
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($bahasa);
	}
	
	function hapusdatabyid(){
		$id = $this->input->post('id');
		
		//echo "DROP TABLE ".$this->db->dbprefix. "daerah_".$id;
		
		$this->m->hapusbyid(array( 'bahasa_id' => $id ),'lang');	
		
		if ($this->db->table_exists("daerah_".$id) ){
			
			$this->db->query("DROP TABLE ".$this->db->dbprefix. "daerah_".$id);
		}
		
	}
	
	
	function hapusdatakatabyid(){
		$id = $this->input->post('id');
		$bahasa = $this->input->post('bahasa');
		
		$where = array(
			'id'=>$id
		);
		$this->m->hapusbyid($where,"daerah_".$bahasa);		
		
	}
}

?>