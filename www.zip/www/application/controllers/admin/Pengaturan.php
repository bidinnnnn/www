<?php
defined('BASEPATH') or exit();

class Pengaturan extends CI_Controller{
	function __construct(){
		parent::__construct();	
		
		$this->load->model('Mymodel','m');
		$this->load->helpers('form');
		$this->load->helpers('url');
		
		if($this->session->userdata('user_level') != 'admin'){
			redirect('auth/profile');
		}
		
		
		$this->user_id = $this->session->userdata('user_id');
		$this->pengaturan_key = $this->session->userdata('pengaturan_key');
	}
	
	function index(){
		$data['title'] = "Pangaturan";
		
        $this->template->load('template','admin/pengaturan',$data);
	}
	
	function daftarpengaturan(){
		
		$where = array(
			'user_id' => $this->user_id,
			'pengaturan_key' => $this->pengaturan_key
		);
		$siswa = $this->db->select('*')->from('pengaturan')->where($where)->order_by('pengaturan_title','asc');
		
		//return $siswa->get()->result();
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode( $siswa->get()->result());
	}

	
	function simpandata(){			
		$d = $this->input->post('data');
		
		$x = array();
		$result = array();
		foreach((array)$d as $tag){
			
			$where = array(
				'pengaturan_key'=>$this->pengaturan_key,
				'user_id'=>$this->user_id,
				'pengaturan_id'=>$tag['pengaturan_id']
			);
			$a = array(
				'pengaturan_value'=>$tag['pengaturan_value']
			);		
			
			$is = $this->db->get_where('pengaturan',$where)->result();
			
			if( count($is) > 0){
			
				$this->db->where($where);
				$this->db->update('pengaturan',(array)$a);		
				
			}else{
				$x[] = array(
					'pengaturan_key'=>$this->pengaturan_key,
					'user_id'=>$this->user_id,
					'pengaturan_id'=>$tag['pengaturan_id'],
					'pengaturan_value'=>$tag['pengaturan_value']
				);
			}
			
		}
		
		//$this->output->set_header('Content-Type: application/json; charset=utf-8');
		//echo json_encode((array)$x);
		if( count( $x ) > 0 ) $this->db->insert_batch('pengaturan',(array)$x);
	}
	
	function ambildatabyid(){
		$id =  $this->input->post('id');
		$where = array(
			'lokasi_id'=>$id,
			'user_id'=>$this->user_id,
			'pengaturan_key'=>$this->pengaturan_key
		);
		$lokasi = $this->m->ambilbyid($where,'lokasi')->result();
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($lokasi);
	}
	
	function hapusdatabyid(){
		$id = $this->input->post('id');
		
		$where = array(
			'lokasi_id'=>$id,
			'user_id'=>$this->user_id,
			'pengaturan_key'=>$this->pengaturan_key
		);
		$this->m->hapusbyid($where,'lokasi');		
		
	}
}

?>