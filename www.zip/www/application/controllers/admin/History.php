<?php
defined('BASEPATH') or exit();

class History extends CI_Controller{
	function __construct(){
		parent::__construct();	
		
		$this->load->model('Mymodel','m');
		$this->load->helpers('form');
		$this->load->helpers('url');
		
		if($this->session->userdata('user_level') != 'admin'){
			redirect('auth/profile');
		}
		
		
		$this->user_id = $this->session->userdata('user_id');
	}
	
	function index(){
		$data['title'] = "History";
		
        $this->template->load('template','admin/history',$data);
	}
	
	
	
	function getRows($params = array()){
        $this->db->select('*');
        $this->db->from('history');
        //filter data by searched keywords
        if(!empty($params['search']['keywords'])){
            $this->db->like('text',$params['search']['keywords']);
        }
        //sort data by ascending or desceding order
        if(!empty($params['search']['sortBy'])){
            $this->db->order_by('waktu',$params['search']['sortBy']);
        }else{
            $this->db->order_by('waktu','desc');
        }
		
        //set start and limit
        if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit'],$params['start']);
        }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit']);
        }
		
        //get records
        $query = $this->db->get();
		
		$data = array();
		foreach($query->result_array() as $row){
			
			$items = array();
			$items['history_id'] = $row['history_id'];
            $items['text'] = substr($row['text'], 0, 150);
			$items['bahasa'] = $row['bahasa'];
			$items['mode'] = $row['mode'];
			$items['waktu'] = $row['waktu'];
				
			
			array_push($data,$items);
		}
		
		
        //return fetched data
        return $data;
    }
	
	function ajaxPaginationData(){
		
        $this->perPage = 10;
        $conditions = array();
        
        //calc offset number
        $page = $this->input->post('page');
        if(!$page){
            $offset = 0;
        }else{
            $offset = $page;
        }
        
        //set conditions for search
        $keywords = $this->input->post('keywords');
        $sortBy = $this->input->post('sortBy');
	
		
        if(!empty($keywords)){
            $conditions['search']['keywords'] = $keywords;
        }
        if(!empty($sortBy)){
            $conditions['search']['sortBy'] = $sortBy;
        }
        if(!empty($limitBy)){
            $this->perPage = (int) $limitBy;
        }
        
		
        //total rows count
        $totalRec = count($this->getRows($conditions));
        
        //pagination configuration
        $config['target']      = '#postList tbody';
        $config['base_url']    = base_url().'history/ajaxPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        $config['link_func']   = 'searchFilter';
		
		
		// integrate bootstrap pagination
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = 'First';
        $config['last_link'] = 'Last';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = 'Prev';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $this->ajax_pagination->initialize($config);
        
        //set start and limit
        $conditions['start'] = $offset;
        $conditions['limit'] = $this->perPage;
        
        //get posts data
        $data['empData'] = $this->getRows($conditions);
		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data['pagination'] = $this->ajax_pagination->create_links();
        
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($data);	
    }
	
	
	function tambahdata(){					
						
		$history_title = $this->input->post('history_title');
		$history_kd = $this->input->post('history_kd');
		if( $history_title == ""){
			$result['pesan'] = "Judul Katalog Kosong!";
		}elseif( $history_kd == ""){
			$result['pesan'] = "Kode Katalog Kosong!";
		}else{
			$result['pesan'] = "";
			$data =  array(
				'user_id'=>$this->user_id,
				'history_title' => $history_title,
				'history_kd' => $history_kd
			);
			

			$this->db->insert('history',$data);
			
			$id = $this->db->insert_id();
			$result['id'] = $id;
			
		}
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($result);
	}
	
	function simpandatabyid(){		
		$id = $this->input->post('id');			
						
		$history_title = $this->input->post('history_title');
		$history_kd = $this->input->post('history_kd');
		if( $history_title == ""){
			$result['pesan'] = "Judul Katalog Kosong!";
		}elseif( $history_kd == ""){
			$result['pesan'] = "Kode Katalog Kosong!";
		}else{
			$result['pesan'] = "";
			
			
			$where = array(
				'history_id'=>$id,
				'user_id'=>$this->user_id
			);
			$data =  array(
				'text' => $text,
				'bahasa' => $bahasa,
				'mode' => $mode
			);
			$this->db->where($where);
			$this->db->update('history',$data);
			$result['id'] = $id;
			
		}
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($result);
	}
	
	function ambildatabyid(){
		$id =  $this->input->post('id');
		$where = array(
			'history_id'=>$id,
			'user_id'=>$this->user_id
		);
		$history = $this->m->ambilbyid($where,'history')->result();
		
		
		$this->output->set_header('Content-Type: application/json; charset=utf-8');
		echo json_encode($history);
	}
	
	function hapusdatabyid(){
		$id = $this->input->post('id');
		
		$where = array(
			'history_id'=>$id,
			'user_id'=>$this->user_id
		);
		$this->m->hapusbyid($where,'history');		
		
	}
}

?>