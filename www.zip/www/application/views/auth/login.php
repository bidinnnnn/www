<!doctype html>
<html lang="en">
   <head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Bade</title>
    <script src="<?php echo base_url('js/jquery.min.js') ?>"></script>	
    <script src="<?php echo base_url('js/jquery-ui.js') ?>"></script>	
	<link rel="icon" type="image/ico" href="<?php echo base_url('img/perpus.ico') ?>"><link rel='dns-prefetch' href='<?php echo base_url();?>' />
    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo base_url('css/jquery-ui.css') ?>" rel="stylesheet">
	<link href="<?php echo base_url('css/custom.css') ?>" rel="stylesheet">
	<link href="<?php echo base_url('css/teamof-elegant-modal-form.css') ?>" rel="stylesheet">
	  <style type="text/css">
	  	.of-elegant-modal .of-intro-container {
		  background-image: url("<?php echo base_url('uploads/sliders/112775666392696333479_slider_1_keluarga.jpg');?>");
		}
		  
	  </style>
	<script type="text/javascript">
		function signin() {
			
			$('.status').empty();
			var username = $('#username').val();
			var password = $('#password').val();
			$.ajax({
				type: 'POST',
				url: '<?php echo base_url(); ?>index.php/auth/signin',
				data:'username='+username+'&password='+password,
				dataType:'json',
				beforeSend: function () {
					$("input").attr('disabled','disabled');
					$("button").attr('disabled','disabled');

					$('.status').html('<div class="alert alert-warning" role="alert">Loading ...</div>');
					$('#loading_ajax').show();
				},
				success: function (hasil) {
					console.log(hasil);
					
					$('#loading_ajax').fadeOut("slow");					
					$('.status').html(hasil.pesan);					
					if(hasil.pesan == ''){		
						window.location.assign("<?php echo base_url();?>index.php/"+hasil.redirect); 
					}else{						
						$("input").removeAttr('disabled');
						$("button").removeAttr('disabled');
					}
				}
			});
		}
	</script>
  </head>

  <body class="text-center" style="padding-top: 10px;">
  
	<div id="loading_ajax"><center style="padding:20px;"><div class="_ani_loading"><span style="clear:both">Memuat...</span></center></div></div>
	  
		<div class="container">  
			<div class="row">
				<div class="py-5 text-center">
					<h2 class="text-light">Bahasa Daerah</h2>
				</div>
			</div>
			<div class="row">
			<div id="loginbox" class="mainbox col-md-4 col-md-offset-4 col-sm-4 col-sm-offset-4">                    
				<div class="panel panel-default" >

					<div class="of-elegant-modal show">
						<div class="container-fluid">
							<div class="row">
								<div class="col-lg-12 px-0">
									<div class="py-4 of-login-container of-show">
										<h3 class="pt-2">Selamat datang!</h3>
										<div class="status"></div>

										 <div class="form-group">
											<div class="of-input-container">
											<div class="of-input-icon"><img src="img/mail.svg"></div>
												<input type="input" class="form-control" id="username" placeholder="Username">
											</div>
										  </div>
										  <div class="form-group">
											<div class="of-input-container">
											<div class="of-input-icon"><img src="img/lock.svg"></div>
												<input type="password" class="form-control" id="password" placeholder="Password">
												<div class="of-input-validation lpassword-toggle-btn show-password"></div>
											</div>
										  </div>

										<div class="text-right">
										<button onclick="signin()" type="button" id="btn-tambah" class="btn btn-block btn-success">MASUK</button> 
										</div>

										<br class="clear"/>
										<!--<a class="of-signup-link of-toggle-link pb-2" href="#">Don't have an account yet? Sign Up!</a>-->
									</div>
								</div> <!--End .col-lg-6 -->
							</div> <!--End .row -->
						</div> <!--End .container-fluid -->
					</div>


				</div>  
			</div>
			</div>
    	</div>

		  <footer class="mastfoot mt-auto">
			<div class="inner">
			  <p class="text-dark">Copyright 2022. Powered by <a href="https://berkarya.kopas.id/">@Zainal Abidin id kopas</a>.</p>
			</div>
		  </footer>
    </div>
	<script src="<?php echo base_url('js/bootstrap.min.js') ?>"></script>
  </body>
</html>
