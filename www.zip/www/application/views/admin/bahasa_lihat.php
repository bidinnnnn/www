<div class="container">


    <input type="hidden" id="_page_current" value="0">
        <div class="row">
            <div class="col-md-8">
				<div class="panel panel-default">
					<div class="panel-heading text-center">
						<b>DATA KATA BAHASA</b>
					</div>
					<div class="panel-body">

						
						<div class="row">
									<div class="col-md-4">
										<input class="form-control" type="text" id="keywords" placeholder="Type keywords to filter posts" onkeyup="searchFilter()"/>
									</div>
									<div class="col-md-4">										
										<a href="#form2" data-toggle="modal" class="btn btn-warning"><span class="glyphicon glyphicon-filter"></span> Filter</a>
										<a href="<?php echo base_url(). "index.php/admin/kata/index"; ?>" class="btn btn-primary">Show All</a>
									</div>
						</div>
						<br/>
						<table id='postList' class="table table-striped table-hover table-bordered">
									<thead>				
										<tr>
											<th class="text-center">NO</th>
											<th>TEXT</th>
											<th class="text-center" width="150"><span class="glyphicon glyphicon-cog"></span></th>
										</tr>
									</thead>
									<tbody></tbody>		
						</table>
						<div id='pagination'></div>
						

						
						<div class="modal fade" id="form2" role="dialog">
							<div class="modal-dialog modal-sm">
								<div class="modal-content">
									<div class="modal-body">
										<div class="row">
											
											
										<div class="col-md-12">
											<label for="limitBy">Limit</label><br/>
											<select class="form-control"  id="limitBy" onchange="searchFilter()">
												<option value="10">10</option>
												<option value="30">30</option>
												<option value="50">50</option>
												<option value="100">100</option>
												<option value="200">200</option>
											</select>
										</div>
											
										<div class="clear"></div>
										</div>
									</div>
									
								</div>
							</div>	
						</div>
						
						
					</div>
				</div>
			</div>

            <!-- Blog Entries Column -->
            <div class="col-md-4">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <input type="hidden" name="bahasa" class="form-control" value="<?php echo $lang;?>" />
                        <label>Indonesia</label>
                        <div class="input-group">
                            <input type="text" name="indonesia" class="form-control" placeholder="Kata Indonesia">
                            <span class="input-group-btn">
								<button onclick="searchFilterKata()" class="btn btn-default" type="button" >
									<span class="glyphicon glyphicon-search"></span></button>
							</span>
                        </div><br>
                        <label>Daerah</label>
                        <input type="text" name="daerah" class="form-control" /><br>
                        <label>Aksara</label>
                        <input type="text" name="aksara" class="form-control" /><br>
                        <div class="text-right">
                            <button onclick="tambahdata()" type="button" id="btn-tambah" class="btn btn-primary">Tambah</button>
                            <button onclick="submit('tambah')" type="button" id="btn-baru" class="btn btn-default">Baru</button>
                            <button onclick="simpandata()" type="button" id="btn-ubah" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </div>
            </div>
		</div>
	</div>
	<script src="<?php echo base_url();?>js/tinymce/tinymce.min.js"></script>
	<script type="text/javascript">
		$('#btn-baru').hide();
		$('#btn-ubah').hide();
		
		searchFilter(0);
		function searchFilter(page_num) {
			page_num = page_num?page_num:0;
			var bahasaBy = $('[name="bahasa"]').val();
			var keywords = $('#keywords').val();
			var limitBy = $('#limitBy').val();
			$.ajax({
				type: 'POST',
				url: '<?php echo base_url(); ?>index.php/admin/bahasa/ajaxPaginationDataKata/'+page_num,
				data:'page='+page_num+'&keywords='+keywords+'&limitBy='+limitBy+'&bahasaBy='+bahasaBy,
				dataType:'json',
				beforeSend: function () {
					$('#loading_ajax').show();
				},
				success: function (responseData) {
                    $('#_page_current').val(page_num);
					$('#pagination').html(responseData.pagination);
					paginationData(responseData.empData);
					$('#loading_ajax').fadeOut("slow");
				}
			});
		}
		
		function searchFilterKata() {
			var y = $('[name="bahasa"]').val();
			var x = $('[name="indonesia"]').val();
			
			$("[name='indonesia']").prop('disabled', true);		
			$("[name='daerah']").prop('disabled', true);		
			$("[name='aksara']").prop('disabled', true);		
			$("[name='bahasa']").prop('disabled', true);			
			
			$('#loading_ajax').show();	
			
			
			$("[name='indonesia']").val(x);			
			$("[name='daerah']").val('');		
			$("[name='aksara']").val('');	
			$("[name='bahasa']").val(y);		
			
			if(x == '' || y == ''){
				alert("Maaf bahasa atau text Indonesia kosong");
				
				$("[name='indonesia']").prop('disabled', false);		
				$("[name='daerah']").prop('disabled', false);	
				$("[name='aksara']").prop('disabled', false);	
				$("[name='bahasa']").prop('disabled', false);
				
				
				$('#loading_ajax').fadeOut("slow");	
			}else{
			
			
			
				$('#btn-tambah').removeClass('btn-primary');
				$('#btn-tambah').addClass('btn-default');
			
				$('#btn-tambah').hide();
				$('#btn-baru').show();
				$('#btn-ubah').show();
				
				$.ajax({
					type:'POST',
					data: 'text='+x+'&bahasa='+y,
					url:'<?php echo base_url('index.php/admin/kata/ambildatabyid') ;?>',
					dataType:'json',
					beforeSend: function () {
						$('#loading_ajax').show();
					},
					success: function(hasil){

						if(hasil.length > 0){

							$("[name='indonesia']").val(hasil[0].indonesia);			
							$("[name='daerah']").val(hasil[0].daerah);		
							$("[name='aksara']").val(hasil[0].aksara);	
						}else{
							
							$('#btn-tambah').removeClass('btn-default');
							$('#btn-tambah').addClass('btn-primary');
							
							$('#btn-tambah').show();
							$('#btn-baru').show();
							$('#btn-ubah').hide();
						}


						$("[name='daerah']").prop('disabled', false);	
						$("[name='aksara']").prop('disabled', false);
							//console.log(hasil);
						$('#loading_ajax').fadeOut("slow");	

					}
				});
			}
			
		}
		
		function paginationData(data) {
			$('#postList tbody').empty();
			var nomor = 1;
			for(emp in data){
				
				var mode_text = "";
				if( data[emp].mode == '1'){
				   mode_text = '<span class="label label-default">'+data[emp].bahasa+'</span> <span class="label label-default">Indonesia</span>';
				}else if( data[emp].mode == '2'){
				   mode_text = '<span class="label label-default">Indonesia</span> <span class="label label-default">'+data[emp].bahasa+'</span>';
				}
				var a = new String("'"+data[emp].indonesia+"'");
				var b = new String("'"+data[emp].daerah+"'");
				var c = new String("'"+data[emp].aksara+"'");
				
				var empRow = '<tr>'+
							'<td class="text-center">'+nomor+'</td>'+
							'<td>'+data[emp].indonesia+'<br><span class="label label-default">'+data[emp].daerah+'</span> <span class="label label-default">'+data[emp].aksara+'</span></td>'+
							'<td class="text-center"><div class="btn-group" role="group"><a onclick="edit('+a+','+b+','+c+')"  class="btn btn-sm btn-warning"><span class="glyphicon glyphicon-pencil"></span></a><a onclick="hapus('+data[emp].id+')" class="btn btn-sm btn-danger"><span class="glyphicon glyphicon-trash"></span></a></div></td>'+
							+'</tr>';
				nomor++;
				$('#postList tbody').append(empRow);					
			}
		}
		
		
		
		function submit(x){
			
			$("[name='indonesia']").val('');			
			$("[name='daerah']").val('');	
			$("[name='aksara']").val('');	
			
			if(x == 'tambah'){
				
						
				$("[name='indonesia']").prop('disabled', false);		
				$("[name='daerah']").prop('disabled', false);		
				$("[name='aksara']").prop('disabled', false);	
				
				$('#btn-tambah').removeClass('btn-default');
				$('#btn-tambah').addClass('btn-primary');
				
				$('#btn-tambah').show();
				$('#btn-baru').hide();
				$('#btn-ubah').hide();
			   
			}
		}
		
		function edit(x,y,z){		
			
			$("[name='indonesia']").prop('disabled', true);		
			$("[name='daerah']").prop('disabled', true);		
			$("[name='aksara']").prop('disabled', true);				
			
			$('#loading_ajax').show();	
			
			$('#btn-tambah').removeClass('btn-primary');
			$('#btn-tambah').addClass('btn-default');
			
			
			$('#btn-tambah').hide();
			$('#btn-baru').show();
			$('#btn-ubah').show();
			
			
			$("[name='indonesia']").val(x);	
			$("[name='daerah']").val(y);			
			$("[name='aksara']").val(z);		
			
			$("[name='daerah']").prop('disabled', false);	
			$("[name='aksara']").prop('disabled', false);
			//console.log(hasil);
			$('#loading_ajax').fadeOut("slow");	
						
			
		}
		
		function tambahdata(){		
			
			$('#btn-tambah').removeClass('btn-primary');
			$('#btn-tambah').addClass('btn-default');
			
			var indonesia = $("[name='indonesia']").val();			
			var daerah = $("[name='daerah']").val();		
			var bahasa = $("[name='bahasa']").val();	
			var aksara = $("[name='aksara']").val();	
			
			$('#loading_ajax').show();	
			
			$.ajax({
				type:'POST',
				data: {
					'indonesia': indonesia,
					'daerah': daerah,
					'bahasa': bahasa,
					'aksara': aksara
				},
				url:'<?php echo base_url('index.php/admin/bahasa/tambahdatakata') ;?>',
				dataType:'json',
				success: function(hasil){
					console.log(hasil);
					
					$('#loading_ajax').fadeOut("slow");
					
					if(hasil.pesan == ''){

                        var page_num = $('#_page_current').val();
                        searchFilter(page_num);

						$('#btn-tambah').removeClass('btn-default');
						$('#btn-tambah').addClass('btn-primary');

						
						$("[name='indonesia']").prop('disabled', false);
						$("[name='daerah']").prop('disabled', false);	
						$("[name='aksara']").prop('disabled', false);
						
						$("[name='indonesia']").val('');			
						$("[name='daerah']").val('');	
						$("[name='aksara']").val('');	
						//bersihkan form
					}else{
						$('#btn-tambah').removeClass('btn-default');
						$('#btn-tambah').addClass('btn-primary');
						
						$('.modal-status').show();
						$('.modal-status').html('<div class="alert alert-danger" role="alert">'+hasil.pesan+'</div>');
						
					}
				}
			});
		}

		
		
		
		function simpandata(){		
			
			$('#btn-tambah').removeClass('btn-primary');
			$('#btn-tambah').addClass('btn-default');
			
			var indonesia = $("[name='indonesia']").val();			
			var daerah = $("[name='daerah']").val();		
			var bahasa = $("[name='bahasa']").val();	
			var aksara = $("[name='aksara']").val();	
			
			$('#loading_ajax').show();	
			
			$.ajax({
				type:'POST',
				data: {
					'indonesia': indonesia,
					'daerah': daerah,
					'bahasa': bahasa,
					'aksara': aksara
				},
				url:'<?php echo base_url('index.php/admin/bahasa/simpandatakatabyid') ;?>',
				dataType:'json',
				success: function(hasil){
					//console.log(hasil);
					
					$('#loading_ajax').fadeOut("slow");
					
					if(hasil.pesan == ''){

                        var page_num = $('#_page_current').val();
                        searchFilter(page_num);

						$('#btn-tambah').removeClass('btn-default');
						$('#btn-tambah').addClass('btn-primary');
						
						
						$('#btn-tambah').show();
						$('#btn-baru').hide();
						$('#btn-ubah').hide();
						
						
						$("[name='indonesia']").prop('disabled', false);
						$("[name='daerah']").prop('disabled', false);	
						$("[name='aksara']").prop('disabled', false);
						
						$("[name='indonesia']").val('');			
						$("[name='daerah']").val('');	
						$("[name='aksara']").val('');	

						//bersihkan form
					}else{
						$('#btn-tambah').removeClass('btn-default');
						$('#btn-tambah').addClass('btn-primary');
						
						$('.modal-status').show();
						$('.modal-status').html('<div class="alert alert-danger" role="alert">'+hasil.pesan+'</div>');
						
					}
				}
			});
		}
	
		function hapus(x){
			var tanya = confirm('Apakah yakin mau hapus data?');
			if(tanya){	
				var bahasa = $("[name='bahasa']").val();	
				
				$.ajax({
				type:'POST',
				data: 'id='+x+'&bahasa='+bahasa,
				url:'<?php echo base_url('index.php/admin/bahasa/hapusdatakatabyid') ;?>',
				success: function(){
                    var page_num = $('#_page_current').val();
                    searchFilter(page_num);
				}
			});
			}
		}	
			
		function republish(x,y){
			$.ajax({
				type:'POST',
				data: 'id='+x+'&panding='+y,
				url:'<?php echo base_url('index.php/admin/kata/republish') ;?>',
				success: function(){					
					searchFilter(0);
				}
			});
		}
	</script>