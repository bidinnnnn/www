<div class="wrapper" style="height: auto; min-height: 100%;">
<div class="container container-small">


        <div class="row">
            <!-- Blog Entries Column -->
            <div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading text-center">
						<b>DATA PENGATURAN</b>
					</div>
					<div class="panel-body">
						<div id="pengaturan"></div>
					</div>
					<div class="panel-footer" style="display: none">					
						<div class="text-right">
							<button onclick="simpandata()" type="button" id="btn-ubah" class="btn btn-primary">Simpan</button> 
						</div>
					</div>
				</div>
			</div>
		</div>
</div>
</div>
	<script src="<?php echo base_url();?>js/tinymce/tinymce.min.js"></script>
	<script type="text/javascript">	
		
		$('.panel-footer').hide();
		submit();
		function submit(){					
				
			$.ajax({
					type: 'POST',
					url: '<?php echo base_url(); ?>index.php/admin/pengaturan/daftarpengaturan',
					dataType:'json',
					beforeSend: function () {
						$('#loading_ajax').show();
					},
					success: function (responseData) {
						//console.log(responseData);
						paginationDataDialogEdit(responseData);
						//$('#form1').modal('hide');
						$('#loading_ajax').fadeOut("slow");
						$('.panel-footer').fadeIn("slow");
					}
			});
		}
		
		function paginationDataDialogEdit(data) {
			$('#pengaturan').empty();
			for(emp in data){	
				
				//console.log(data[emp].tanggal);
				var empRow = '<div class="pengaturan_row">'+
					'<label id="pengaturan_title">'+data[emp].pengaturan_title+'</label>'+
					'<input type="hidden" name="pengaturan_id" value="'+data[emp].pengaturan_id+'">'+
					'<input type="text" name="pengaturan_value" value="'+data[emp].pengaturan_value+'" class="form-control" />'+
					'</div>';
				$('#pengaturan').append(empRow);					
			}
		}
		
		function simpandata(){		
							
			$('#btn-ubah').removeClass('btn-primary');
			$('#btn-ubah').addClass('btn-default');
			
			$('#pengaturan_value').prop('disabled', true);
			
			var updateArray = [];
  			$(".pengaturan_row").each(function() {
				var pengaturan_id   = $(this).find("[name='pengaturan_id']").val();
				var pengaturan_value = $(this).find("[name='pengaturan_value']").val();
				updateArray.push({
					pengaturan_id: pengaturan_id,
					pengaturan_value: pengaturan_value
				});
			});
			
			//console.log(updateArray);
			
			$('#loading_ajax').show();			
			
			$.ajax({
				type:'POST',
				data: {
					'data' : updateArray
				},
				url:'<?php echo base_url('index.php/admin/pengaturan/simpandata') ;?>',
				success: function(){
					//console.log(hasil);
					
					$('#loading_ajax').fadeOut("slow");		
					submit();
					$('#btn-ubah').removeClass('btn-default');
					$('#btn-ubah').addClass('btn-primary');
					$('#pengaturan_value').prop('disabled', false);
				}
			});
		}
	
		function hapus(x){
			var tanya = confirm('Apakah yakin mau hapus data?');
			if(tanya){
				$.ajax({
				type:'POST',
				data: 'id='+x,
				url:'<?php echo base_url('index.php/admin/lokasi/hapusdatabyid') ;?>',
				success: function(){					
					searchFilter(0);
				}
			});
			}
		}	
			
		function republish(x,y){
			$.ajax({
				type:'POST',
				data: 'id='+x+'&panding='+y,
				url:'<?php echo base_url('index.php/admin/lokasi/republish') ;?>',
				success: function(){					
					searchFilter(0);
				}
			});
		}
	</script>