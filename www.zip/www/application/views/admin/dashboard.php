<div class="container container-medium">
    <div class="row">
        <div class="col-md-12">
            <div class="small-box bg-blue">
                <div class="inner">
                    <h3>Welcome</h3>
                    <p>Selamat Datang di Bade</p>
                </div>
                <div class="icon">
                    <i class="glyphicon glyphicon-book"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $('#loading_ajax').fadeOut("slow");
</script>