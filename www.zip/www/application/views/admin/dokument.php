
	<div class="container">


        <div class="py-5 text-center">
        <h2>Docs</h2>
        <p class="lead">Petunjuk dan pedoman penggunaan.</p>
	  
        <div class="alert alert-light" role="alert">Maaf Dokumen petunjuk masih dalam tahap penyempurnaan!
	</div>
	
	<script type="text/javascript">
		$('#loading_ajax').fadeOut("slow");
	</script>