<div class="container">


    <input type="hidden" id="_page_current" value="0">
        <div class="row">
            <!-- Blog Entries Column -->
            <div class="col-md-8">
				<div class="panel panel-default">
					<div class="panel-heading text-center">
						<b>DATA KATA</b>
					</div>
					<div class="panel-body">

						
						<div class="row">
									<div class="col-md-4">
										<input class="form-control" type="text" id="keywords" placeholder="Type keywords to filter posts" onkeyup="searchFilter()"/>
									</div>
									<div class="col-md-4">										
										<a href="#form2" data-toggle="modal" class="btn btn-warning"><span class="glyphicon glyphicon-filter"></span> Filter</a>
										<a href="<?php echo base_url(). "index.php/admin/kata/index"; ?>" class="btn btn-primary">Show All</a>
									</div>
						</div>
						<br/>
						<table id='postList' class="table table-striped table-hover table-bordered">
									<thead>				
										<tr>
											<th class="text-center">NO</th>
											<th class="text-center">TEXT</th>
											<th class="text-center">TOP</th>
											<th class="text-center" width="150"><span class="glyphicon glyphicon-cog"></span></th>
										</tr>
									</thead>
									<tbody></tbody>		
						</table>
						<div id='pagination'></div>
						

						
						<div class="modal fade" id="form2" role="dialog">
							<div class="modal-dialog modal-smn">
								<div class="modal-content">
									<div class="modal-body">
										<div class="row">
											
											
										<div class="col-md-4">
											<label for="limitBy">Limit</label><br/>
											<select class="form-control"  id="limitBy" onchange="searchFilter()">
												<option value="50">50</option>
												<option value="100">100</option>
												<option value="200">200</option>
											</select>
										</div>
										<div class="col-md-8">
											<label for="bahasaBy">Bahasa</label><br/>
											<select class="form-control"  id="bahasaBy" onchange="searchFilter()">
											</select>
										</div>
											
										<div class="clear"></div>
										</div>
									</div>
									
								</div>
							</div>	
						</div>
						
						
					</div>
				</div>
			</div>


            <div class="col-md-4">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <label>Bahasa</label>
                        <select class="form-control" name="bahasa">
                            <option value="">Pilih Bahasa</option>
                            <?php foreach($bahasa as $item ){?>
                                <option value="<?php echo $item['bahasa_id']?>"><?php echo $item['bahasa_desc']?></option>
                            <?php }?>
                        </select><br>
                        <label>Indonesia</label>
                        <div class="input-group">
                            <input type="text" name="indonesia" class="form-control" placeholder="Kata Indonesia">
                            <span class="input-group-btn">
								<button onclick="searchFilterKata()" class="btn btn-default" type="button" >
									<span class="glyphicon glyphicon-search"></span></button>
							</span>
                        </div><br>
                        <label>Daerah</label>
                        <input type="text" name="daerah" class="form-control" /><br>
                        <label>Aksara</label>
                        <input type="text" name="aksara" class="form-control" /><br>
                        <div class="text-right">
                            <button onclick="tambahdata()" type="button" id="btn-tambah" class="btn btn-primary">Tambah</button>
                            <button onclick="submit('tambah')" type="button" id="btn-baru" class="btn btn-default">Baru</button>
                            <button onclick="simpandata()" type="button" id="btn-ubah" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </div>
            </div>
		</div>
	</div>
	<script src="<?php echo base_url();?>js/tinymce/tinymce.min.js"></script>
	<script type="text/javascript">
		$('#btn-baru').hide();
		$('#btn-ubah').hide();
		
		callBahasa();
		
		function callBahasa(){			
			$('#bahasaBy')
				.children()
				.remove()
				.end()
				.append('<option value="">Loading...</option>');
			
			$.ajax({
				type:'POST',
				url:'<?php echo base_url('index.php/admin/kata/bahasa') ;?>',
				dataType: 'json',
				success: function(data){
					var html = '<option value=\'\'>--Semua Bahasa--</option>';
					var i;
					for(i=0; i<data.length; i++){
						html += '<option value="'+data[i].bahasa_id+'">'+data[i].bahasa_desc+'</option>';
					}
					$('#bahasaBy').empty();
					$('#bahasaBy').html(html);
				}
			});
		}
		
		searchFilter(0);
		function searchFilter(page_num) {
			page_num = page_num?page_num:0;
			var keywords = $('#keywords').val();
			var limitBy = $('#limitBy').val();
			var bahasaBy = $('#bahasaBy').val();

			$.ajax({
				type: 'POST',
				url: '<?php echo base_url(); ?>index.php/admin/kata/ajaxPaginationData/'+page_num,
				data:'page='+page_num+'&keywords='+keywords+'&limitBy='+limitBy+'&bahasaBy='+bahasaBy,
				dataType:'json',
				beforeSend: function () {
					$('#loading_ajax').show();
				},
				success: function (responseData) {

				    $('#_page_current').val(page_num);

					$('#pagination').html(responseData.pagination);
					paginationData(responseData.empData);
					$('#loading_ajax').fadeOut("slow");
				}
			});
		}
		
		function searchFilterKata() {
			var y = $('[name="bahasa"]').val();
			var x = $('[name="indonesia"]').val();
			
			$("[name='indonesia']").prop('disabled', true);		
			$("[name='daerah']").prop('disabled', true);		
			$("[name='aksara']").prop('disabled', true);		
			$("[name='bahasa']").prop('disabled', true);			
			
			$('#loading_ajax').show();	
			
			
			$("[name='indonesia']").val(x);			
			$("[name='daerah']").val('');		
			$("[name='aksara']").val('');	
			$("[name='bahasa']").val(y);		
			
			if(x = '' || y == ''){
				alert("Maaf bahasa atau text Indonesia kosong");
				
				$("[name='indonesia']").prop('disabled', false);		
				$("[name='daerah']").prop('disabled', false);	
				$("[name='aksara']").prop('disabled', false);	
				$("[name='bahasa']").prop('disabled', false);
				
				
				$('#loading_ajax').fadeOut("slow");	
			}else{
			
			
			
				$('#btn-tambah').removeClass('btn-primary');
				$('#btn-tambah').addClass('btn-default');
			
				$('#btn-tambah').hide();
				$('#btn-baru').show();
				$('#btn-ubah').show();
				
				$.ajax({
					type:'POST',
					data: 'text='+x+'&bahasa='+y,
					url:'<?php echo base_url('index.php/admin/kata/ambildatabyid') ;?>',
					dataType:'json',
					beforeSend: function () {
						$('#loading_ajax').show();
					},
					success: function(hasil){

						if(hasil.length > 0){

							$("[name='indonesia']").val(hasil[0].indonesia);			
							$("[name='daerah']").val(hasil[0].daerah);		
							$("[name='aksara']").val(hasil[0].aksara);	
						}


						$("[name='daerah']").prop('disabled', false);	
						$("[name='aksara']").prop('disabled', false);
							//console.log(hasil);
						$('#loading_ajax').fadeOut("slow");	

					}
				});
			}
			
		}
		
		function paginationData(data) {
			$('#postList tbody').empty();
			var nomor = 1;
			for(emp in data){
				
				var mode_text = "";
				if( data[emp].mode == '1'){
				   mode_text = '<span class="label label-default">'+data[emp].bahasa+'</span> <span class="label label-default">Indonesia</span>';
				}else if( data[emp].mode == '2'){
				   mode_text = '<span class="label label-default">Indonesia</span> <span class="label label-default">'+data[emp].bahasa+'</span>';
				}
				var a = new String("'"+data[emp].text+"'").toString();
				var b = new String("'"+data[emp].bahasa+"'").toString();
				
				var empRow = '<tr>'+
							'<td class="text-center">'+nomor+'</td>'+
							'<td>'+data[emp].text+'<br>'+mode_text+'</td>'+
							'<td class="text-center"><span class="label label-default">'+data[emp].jumlah+'</span></td>'+
							'<td class="text-center"><div class="btn-group" role="group"><a onclick="edit('+a+','+b+')"  class="btn btn-sm btn-warning"><span class="glyphicon glyphicon-pencil"></span></a><a onclick="hapus('+a+','+b+')" class="btn btn-sm btn-danger"><span class="glyphicon glyphicon-trash"></span></a></div></td>'+
							+'</tr>';
				nomor++;
				$('#postList tbody').append(empRow);					
			}
		}
		
		
		
		function submit(x){
			
			$("[name='indonesia']").val('');			
			$("[name='daerah']").val('');		
			$("[name='bahasa']").val('');	
			$("[name='aksara']").val('');	
			
			if(x == 'tambah'){
				
						
				$("[name='indonesia']").prop('disabled', false);		
				$("[name='daerah']").prop('disabled', false);		
				$("[name='aksara']").prop('disabled', false);		
				$("[name='bahasa']").prop('disabled', false);	
				
				$('#btn-tambah').removeClass('btn-default');
				$('#btn-tambah').addClass('btn-primary');
				
				$('#btn-tambah').show();
				$('#btn-baru').hide();
				$('#btn-ubah').hide();
			   
			}
		}
		
		function edit(x,y){		
			
			$("[name='indonesia']").prop('disabled', true);		
			$("[name='daerah']").prop('disabled', true);		
			$("[name='aksara']").prop('disabled', true);		
			$("[name='bahasa']").prop('disabled', true);			
			
			$('#loading_ajax').show();	
			
			$('#btn-tambah').removeClass('btn-primary');
			$('#btn-tambah').addClass('btn-default');
			
			
			$('#btn-tambah').hide();
			$('#btn-baru').show();
			$('#btn-ubah').show();
			
			
			$("[name='indonesia']").val(x);			
			$("[name='daerah']").val('');		
			$("[name='aksara']").val('');	
			$("[name='bahasa']").val(y);		
			
			$.ajax({
				type:'POST',
				data: 'text='+x+'&bahasa='+y,
				url:'<?php echo base_url('index.php/admin/kata/ambildatabyid') ;?>',
				dataType:'json',
				success: function(hasil){
					
					if(hasil.length > 0){
						
						$("[name='indonesia']").val(hasil[0].indonesia);			
						$("[name='daerah']").val(hasil[0].daerah);		
						$("[name='aksara']").val(hasil[0].aksara);	
					}
						
					
					$("[name='daerah']").prop('disabled', false);	
					$("[name='aksara']").prop('disabled', false);
						//console.log(hasil);
					$('#loading_ajax').fadeOut("slow");	
						
				}
			});
			
		}
		
		function tambahdata(){		
			
			$('#btn-tambah').removeClass('btn-primary');
			$('#btn-tambah').addClass('btn-default');
			
			var indonesia = $("[name='indonesia']").val();			
			var daerah = $("[name='daerah']").val();		
			var bahasa = $("[name='bahasa']").val();	
			var aksara = $("[name='aksara']").val();	
			
			$('#loading_ajax').show();	
			
			$.ajax({
				type:'POST',
				data: {
					'indonesia': indonesia,
					'daerah': daerah,
					'bahasa': bahasa,
					'aksara': aksara
				},
				url:'<?php echo base_url('index.php/admin/kata/tambahdata') ;?>',
				dataType:'json',
				success: function(hasil){
					//console.log(hasil);
					
					$('#loading_ajax').fadeOut("slow");
					
					if(hasil.pesan == ''){

                        var page_num = $('#_page_current').val();
						searchFilter(page_num);

						$('#btn-tambah').removeClass('btn-default');
						$('#btn-tambah').addClass('btn-primary');

						
						$("[name='indonesia']").prop('disabled', false);
						$("[name='daerah']").prop('disabled', false);
						$("[name='bahasa']").prop('disabled', false);		
						$("[name='aksara']").prop('disabled', false);
						
						$("[name='indonesia']").val('');			
						$("[name='daerah']").val('');		
						$("[name='bahasa']").val('');	
						$("[name='aksara']").val('');	
						//bersihkan form
					}else{
						$('#btn-tambah').removeClass('btn-default');
						$('#btn-tambah').addClass('btn-primary');
						
						$('.modal-status').show();
						$('.modal-status').html('<div class="alert alert-danger" role="alert">'+hasil.pesan+'</div>');
						
					}
				}
			});
		}

		
		
		
		function simpandata(){		
			
			$('#btn-tambah').removeClass('btn-primary');
			$('#btn-tambah').addClass('btn-default');
			
			var indonesia = $("[name='indonesia']").val();			
			var daerah = $("[name='daerah']").val();		
			var bahasa = $("[name='bahasa']").val();	
			var aksara = $("[name='aksara']").val();	
			
			$('#loading_ajax').show();	
			
			$.ajax({
				type:'POST',
				data: {
					'indonesia': indonesia,
					'daerah': daerah,
					'bahasa': bahasa,
					'aksara': aksara
				},
				url:'<?php echo base_url('index.php/admin/kata/simpandatabyid') ;?>',
				dataType:'json',
				success: function(hasil){
					//console.log(hasil);
					
					$('#loading_ajax').fadeOut("slow");
					
					if(hasil.pesan == ''){


                        var page_num = $('#_page_current').val();
                        searchFilter(page_num);

						$('#btn-tambah').removeClass('btn-default');
						$('#btn-tambah').addClass('btn-primary');
						
						
						$('#btn-tambah').show();
						$('#btn-baru').hide();
						$('#btn-ubah').hide();
						
						
						$("[name='indonesia']").prop('disabled', false);
						$("[name='daerah']").prop('disabled', false);
						$("[name='bahasa']").prop('disabled', false);		
						$("[name='aksara']").prop('disabled', false);
						
						$("[name='indonesia']").val('');			
						$("[name='daerah']").val('');		
						$("[name='bahasa']").val('');	
						$("[name='aksara']").val('');	

						//bersihkan form
					}else{
						$('#btn-tambah').removeClass('btn-default');
						$('#btn-tambah').addClass('btn-primary');
						
						$('.modal-status').show();
						$('.modal-status').html('<div class="alert alert-danger" role="alert">'+hasil.pesan+'</div>');
						
					}
				}
			});
		}
	
		function hapus(x,y){
			var tanya = confirm('Apakah yakin mau hapus data?');
			if(tanya){
				$.ajax({
				type:'POST',
				data: 'text='+x+'&bahasa='+y,
				url:'<?php echo base_url('index.php/admin/kata/hapusdatabyid') ;?>',
				success: function(){
                    var page_num = $('#_page_current').val();
                    searchFilter(page_num);
				}
			});
			}
		}	
			
		function republish(x,y){
			$.ajax({
				type:'POST',
				data: 'id='+x+'&panding='+y,
				url:'<?php echo base_url('index.php/admin/kata/republish') ;?>',
				success: function(){
                    var page_num = $('#_page_current').val();
                    searchFilter(page_num);
				}
			});
		}
	</script>