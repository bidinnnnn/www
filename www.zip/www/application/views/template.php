<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<title><?php echo $title?></title>

	
    <script src="<?php echo base_url('js/jquery.min.js') ?>"></script>	
    <script src="<?php echo base_url('js/jquery-ui.js') ?>"></script>	
    <script src="<?php echo base_url('js/bootstrap-tagsinput.min.js') ?>"></script>	
    <script src="<?php echo base_url('js/jquery-ui-timepicker-addon.min.js') ?>"></script>	
    	
	<link rel="icon" type="image/ico" href="<?php echo base_url('img/logo.ico') ?>"><link rel='dns-prefetch' href='<?php echo base_url();?>' />
	
	<link href="<?php echo base_url('css/bootstrap.min.css') ?>" rel="stylesheet">
	<link href="<?php echo base_url('css/jquery-ui.css') ?>" rel="stylesheet">
	<link href="<?php echo base_url('css/custom.css') ?>" rel="stylesheet">
	<link href="<?php echo base_url('css/bootstrap-tagsinput.css') ?>" rel="stylesheet">
	<link href="<?php echo base_url('css/jquery-ui-timepicker-addon.min.css') ?>" rel="stylesheet">
	<style type="text/css">
		/*body{
			background: #ddd url("<?php echo base_url('img/bg3.png') ?>") right center repeat;
		}*/
      	.navbar-inverse{background-color:  #fff; border-color: #ddd;}
		.navbar-inverse .navbar-nav>li>a, .navbar-inverse .navbar-nav>li>a:focus, .navbar-inverse .navbar-nav>li>a:hover {
			color: #000;
		}
		.navbar-inverse .navbar-toggle,
		.navbar-inverse .navbar-toggle:focus, 
		.navbar-inverse .navbar-toggle:hover {
			background-color: #fff;
			border-color: #fff;
		}
		.navbar-inverse .navbar-toggle .icon-bar{
			background-color: #000;
		}
		
		.inset {
		  width: 32px;
		  height: 32px;
		  border-radius: 50%;
		  margin-top: 8px;
		  background-color: transparent !important;
		  z-index: 999;
		}

		.inset img {
		  border-radius: inherit;
		  width: inherit;
		  height: inherit;
		  display: block;
		  position: relative;
		  z-index: 998;
		}
		
		.navbar-brand {
			/*padding: 0;*/
		}
		
		.brand-centered {
		  display: flex;
		  justify-content: center;
		  position: absolute;
		  width: 100%;
		  left: 0;
		  top: 0;
		}
		.brand-centered .navbar-brand {
		  display: flex;
		  align-items: center;
		}
		.navbar-toggle {
			z-index: 1;
		}
		
		.navbar-brand {
		  padding: 0px;
		}
		.navbar-brand>img {
		  height: 32px;
		  padding: 15px;
		  width: auto;
		}


    </style>
	<style id="jsbin-css">
		@media (min-width:767px){
		.navbar-inverse .navbar-nav>.open>a, .navbar-inverse .navbar-nav>.open>a:focus, .navbar-inverse .navbar-nav>.open>a:hover{
			background: #fff;
			    color: #555;
			
		}
		@media (min-width:768px) { 

		  .nav-bg {
				height: 0px;
				width: 100%;
				position: absolute;
				top: 50px;
				background: #fff;
			  	-webkit-box-shadow: 0px 3px 3px 0px rgba(0,0,0,0.09);
			  -moz-box-shadow: 0px 3px 3px 0px rgba(0,0,0,0.09);
			  box-shadow: 0px 3px 3px 0px rgba(0,0,0,0.09);
			}

			.menu-open .nav-bg { height: 50px } /* change to your height of the child menu */

		}

		.navbar-nav.nav > li { position: static }

		.navbar-nav.nav .dropdown-menu {
			left: 0 !important;
			right: 0 !important;
			box-shadow: none;
			border: none;
			margin: 0 auto;
			max-width: 1170px;
			background: transparent;
			padding: 0;
		}

		.navbar-nav.nav .dropdown-menu > li { float: left }

		.navbar-nav.nav .dropdown-menu > li > a {
			width: auto !important;
			background: transparent;
			line-height: 49px;
			padding-top: 0;
			padding-bottom: 0;
			margin: 0;
		}
		}
	}

	</style>

	<script type="text/javascript">var base_url = "<?php echo base_url(); ?>";</script>
</head>
<body id="body">
	
	<div id="loading_ajax"><center style="padding:20px;"><div class="_ani_loading"><span style="clear:both">Memuat...</span></center></div></div>
	
	<nav class="navbar <?php if($this->uri->segment(3) == 'mulai'){?>navbar-ujian<?php }else{?>navbar-inverse<?php }?> navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">			
					<?php if($this->session->userdata('user_level') == 'admin'){?>
					<li><a href="<?php echo base_url();?>index.php/admin/dashboard"><span class="glyphicon glyphicon-home"></span></a></li>
					<li><a href="<?php echo base_url();?>index.php/admin/history"><span class="glyphicon glyphicon-bullhorn"></span> History</a></li>
					<li><a href="<?php echo base_url();?>index.php/admin/kata"><span class="glyphicon glyphicon-bullhorn"></span> Kata</a></li>
					<li><a href="<?php echo base_url();?>index.php/admin/bahasa"><span class="glyphicon glyphicon-bullhorn"></span> Bahasa</a></li>
					<?php }?>
				</ul>
				<ul class="nav navbar-nav navbar-right">
				  	<li>
						<div class="inset">
							<?php $foto = $this->session->userdata('foto');?>
					  		<img src="<?php if( $foto != '' && file_exists('uploads/users/'.$foto) ){ echo base_url('uploads/users/'.$foto); }else{ echo base_url('img/avatar.png');}?>">
						</div>
				  	</li>
					<li><a href="<?php echo base_url().'index.php/auth/profile';?>">Hallo, <?php echo $this->session->userdata('username');?></a></li>
					<li><a href="<?php echo base_url().'index.php/admin/pesan'; ?>" title="Pesan"><span class="glyphicon glyphicon-bell"></span>
					<li><a href="<?php echo base_url().'index.php/admin/pengaturan'; ?>" title="Pengaturan"><span class="glyphicon glyphicon-cog"></span></li></a>
					<li><a href="<?php echo base_url().'index.php/auth/logout'; ?>" title="Logout"><span class="glyphicon glyphicon-off"></span></li></a>
				</ul>
			</div><!-- /.navbar-collapse -->
		</div>
	</nav>

<?php 
echo $contents 
?>
	
	<footer class="mastfoot mt-auto">
        <div class="inner text-center">
          <p class="text-dark">Copyright 2018. Versi 2.0.2. Powered by <a href="https://berkarya.kopas.id/">@KopasProjects</a>.</p>
        </div>
</footer>
<script src="<?php echo base_url('js/bootstrap.min.js') ?>"></script>
<script id="jsbin-javascript">

$( '.navbar' ).append( '<span class="nav-bg"></span>' );

$('.dropdown-toggle').click(function () { 
  
  if (!$(this).parent().hasClass('open')) {
  
     $('html').addClass('menu-open');  
    
  } else {
    
     $('html').removeClass('menu-open');  
	 

  }
    
});


$(document).on('click touchstart', function (a) {
        if ($(a.target).parents().index($('.navbar-nav')) == -1) {
                $('html').removeClass('menu-open');  
        }
});


</script>
</body>
</html>
