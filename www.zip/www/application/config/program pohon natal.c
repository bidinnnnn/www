#include<iostream>
#include<stdio.h>

int main()
{
	int i, j, k;
	for (int i=1;i<=7;i++){
		for(k=i;k<=6;k++){
			printf(" ");
		}
		for(int j=1;j<=i;j++){
			printf("* ");
		}
		printf("\n");
	}
	
	for(int i=4;i<=7;i++){
		for(k=i;k<=6;k++){
			printf(" ");
		}
		for(int j=l;j<=i;j++){
			printf("* ");
		}
		printf("\n");
	}
	return 0;
}